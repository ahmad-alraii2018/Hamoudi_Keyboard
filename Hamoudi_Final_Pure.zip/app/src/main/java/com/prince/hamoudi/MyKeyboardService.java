package com.prince.hamoudi;

import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.KeyEvent;
import android.view.View;
import android.view.HapticFeedbackConstants;
import android.view.inputmethod.InputConnection;
import java.util.HashMap;

public class MyKeyboardService extends InputMethodService implements KeyboardView.OnKeyboardActionListener {
    private KeyboardView kv;
    private Keyboard currentKeyboard;
    private Keyboard keyboardNormal;
    private Keyboard keyboardHamoudi1;
    private Keyboard keyboardHamoudi2;
    private boolean isHamoudi1 = false;
    private boolean isHamoudi2 = false;

    private static final HashMap<Character, String> zakh1 = new HashMap<>();
    private static final HashMap<Character, String> zakh2 = new HashMap<>();

    static {
        // زخرفة البرنس حمودي الأولى (الممدودة الفخمة) - 35 حرفاً
        zakh1.put('ا', "اّ"); zakh1.put('ب', "بّـ"); zakh1.put('ت', "تّـ"); zakh1.put('ث', "ثّـ");
        zakh1.put('ج', "جّـ"); zakh1.put('ح', "حّـ"); zakh1.put('خ', "خّـ"); zakh1.put('د', "دّ");
        zakh1.put('ذ', "ذّ"); zakh1.put('ر', "رّ"); zakh1.put('ز', "زّ"); zakh1.put('س', "سّـ");
        zakh1.put('ش', "شّـ"); zakh1.put('ص', "صّـ"); zakh1.put('ض', "ضّـ"); zakh1.put('ط', "طّـ");
        zakh1.put('ظ', "ظّـ"); zakh1.put('ع', "عّـ"); zakh1.put('غ', "غّـ"); zakh1.put('ف', "فّـ");
        zakh1.put('ق', "قّـ"); zakh1.put('ك', "كّـ"); zakh1.put('ل', "لّـ"); zakh1.put('م', "ہمّ");
        zakh1.put('ن', "نّـ"); zakh1.put('ه', "هہّ"); zakh1.put('و', "وّ"); zakh1.put('ي', "يہّ");
        zakh1.put('ة', "ةّ"); zakh1.put('ى', "ىّ"); zakh1.put('ء', "ءّ"); zakh1.put('ئ', "ئّـ");
        zakh1.put('ؤ', "ؤّ"); zakh1.put('إ', "إّ"); zakh1.put('أ', "أّ"); zakh1.put('آ', "آّ");

        // زخرفة البرنس حمودي الثانية (التشكيل والحركات) - 35 حرفاً
        zakh2.put('ا', "آْ"); zakh2.put('ب', "بَ"); zakh2.put('ت', "تَ"); zakh2.put('ث', "ثَ");
        zakh2.put('ج', "جَ"); zakh2.put('ح', "حَ"); zakh2.put('خ', "خَ"); zakh2.put('د', "دَ");
        zakh2.put('ذ', "ذَ"); zakh2.put('ر', "رَ"); zakh2.put('ز', "زَ"); zakh2.put('س', "سَ");
        zakh2.put('ش', "شَ"); zakh2.put('ص', "صَ"); zakh2.put('ض', "ضَ"); zakh2.put('ط', "طَ");
        zakh2.put('ظ', "ظَ"); zakh2.put('ع', "عَ"); zakh2.put('غ', "غَ"); zakh2.put('ف', "فَ");
        zakh2.put('ق', "قَ"); zakh2.put('ك', "كَ"); zakh2.put('ل', "لَ"); zakh2.put('م', "مَ");
        zakh2.put('ن', "نَ"); zakh2.put('ه', "هَ"); zakh2.put('و', "وَ"); zakh2.put('ي', "يَ");
        zakh2.put('ة', "ةَ"); zakh2.put('ى', "ىَ"); zakh2.put('ء', "ءَ"); zakh2.put('ئ', "ئَ");
        zakh2.put('ؤ', "ؤَ"); zakh2.put('إ', "إَ"); zakh2.put('أ', "أَ"); zakh2.put('آ', "آَ");
    }

    @Override
    public View onCreateInputView() {
        kv = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        keyboardNormal = new Keyboard(this, R.xml.qwerty);
        keyboardHamoudi1 = new Keyboard(this, R.xml.zakhrafa_layout1);
        keyboardHamoudi2 = new Keyboard(this, R.xml.zakhrafa_layout2);
        
        currentKeyboard = keyboardNormal;
        kv.setKeyboard(currentKeyboard);
        kv.setOnKeyboardActionListener(this);
        return kv;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (primaryCode) {
            case -5: 
                ic.deleteSurroundingText(1, 0);
                break;
            case -10: 
                isHamoudi1 = !isHamoudi1;
                isHamoudi2 = false;
                currentKeyboard = isHamoudi1 ? keyboardHamoudi1 : keyboardNormal;
                kv.setKeyboard(currentKeyboard);
                break;
            case -20: 
                isHamoudi2 = !isHamoudi2;
                isHamoudi1 = false;
                currentKeyboard = isHamoudi2 ? keyboardHamoudi2 : keyboardNormal;
                kv.setKeyboard(currentKeyboard);
                break;
            case -100: 
                ic.commitText("ٰۣۗٛۧۙۙۗ مـنـوّر الـدنـيـا يـا قـلـبـي ٰۣۗٛۧۙۙۗ", 1);
                break;
            case -200: 
                ic.commitText("ٰۣۗٛۧۙۙۗ الـبـرنـس حـمـودي يـدعـس غـصـب عـن الـكـل ٰۣۗٛۧۙۙۗ", 1);
                break;
            case -4: 
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                break;
            default:
                char code = (char) primaryCode;
                if (isHamoudi1 && zakh1.containsKey(code)) {
                    ic.commitText(zakh1.get(code), 1);
                } else if (isHamoudi2 && zakh2.containsKey(code)) {
                    ic.commitText(zakh2.get(code), 1);
                } else {
                    ic.commitText(String.valueOf(code), 1);
                }
        }
    }

    @Override 
    public void onPress(int primaryCode) {
        if (kv != null) {
            kv.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
    }

    @Override public void onRelease(int primaryCode) {}
    @Override public void onText(CharSequence text) {}
    @Override public void swipeLeft() {}
    @Override public void swipeRight() {}
    @Override public void swipeDown() {}
    @Override public void swipeUp() {}
}
